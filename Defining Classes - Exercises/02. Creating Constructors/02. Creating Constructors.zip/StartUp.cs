﻿using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main()
        {
            //  Person human01 = new Person(13);
            //  Person human02 = new Person("Genadi");
            //  Person human00 = new Person();
            //  Console.WriteLine("Hello World!");
        }
    }
}
