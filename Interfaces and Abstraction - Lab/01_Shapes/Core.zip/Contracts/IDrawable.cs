﻿namespace Shapes.Contracts
{
  public  interface IDrawable
    {
/// <summary>
/// This is method For Drawing The Form
/// </summary>
/// <param name="symbol">This is the symbol with which the form will be drawn</param>

        void Draw();
    }
}